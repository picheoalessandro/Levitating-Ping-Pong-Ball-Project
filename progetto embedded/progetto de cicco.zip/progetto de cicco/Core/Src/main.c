/* USER CODE BEGIN Header */
/**
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "vl53l0x_api.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum
{
    CONTROL_MODE_SETPOINT = 0,
    CONTROL_MODE_SINE = 1
} ControlMode_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* VL53L0X */
#define VL53L0X_ADDRESS_7_BIT          0x29
#define VL53L0X_ADDRESS_HAL            (VL53L0X_ADDRESS_7_BIT << 1)

#define SENSOR_TEST_ENABLE             1
#define PID_CONTROL_ENABLE             1

#define SENSOR_TO_BOTTOM_MM            760
#define SETPOINT_FINAL_MM              450

/*
 * La modalità predefinita è quella del setpoint fisso,
 * ma da PuTTY posso scegliere tra setpoint fisso e variabile sinusoidale
 * digitando 0 o 1; la sinusoide è s(t) = 450 + 75*sin(2*pi*t/15s)
 */
#define DEFAULT_CONTROL_MODE           CONTROL_MODE_SETPOINT
#define SINE_CENTER_MM                 450
#define SINE_AMPLITUDE_MM              75
#define SINE_PERIOD_MS                 15000U

#define CONTROL_PERIOD_MS              60

/* Termini PID. */

#define KP_NUM                         20355
#define KP_DEN                         100000    /* Kp = 0.20355 %/mm */

#define KI_NUM                         1262
#define KI_DEN                         100000    /* Ki = 0.01262 %/mm/ciclo */

#define PID_SCALE                     1000  /* 1% = 1000 unità: per calcolare contributi PID al millesimo */
#define I_TERM_SCALE                   PID_SCALE
#define I_TERM_MIN_PERCENT             -6
#define I_TERM_MAX_PERCENT             6
#define DUTY_FEEDFORWARD_PERCENT       24


#define KD_NUM                         81549
#define KD_DEN                         100000    /* Kd = 0.81549 %/mm sul delta altezza */
#define D_TERM_MAX_PERCENT             20

/* Limiti assoluti del duty. */
#define DUTY_MIN                       0
#define DUTY_MAX                       80

/* Sicurezza su misure non valide consecutive. */
#define MAX_INVALID_MEASUREMENTS       5

/* Periodo di stampa su UART del log. */
#define UART_LOG_PERIOD_MS             300

/* Pulsante USER B1 come stop software */
#define ENABLE_BUTTON_EMERGENCY_STOP   1

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

volatile uint8_t sensore_trovato = 0;
volatile uint32_t errore_i2c = 0;

char messaggio_uart[512];

VL53L0X_Dev_t sensore;
VL53L0X_RangingMeasurementData_t misura;
VL53L0X_Error stato_vl53;

uint32_t ref_spad_count = 0;
uint8_t is_aperture_spads = 0;
uint8_t vhv_settings = 0;
uint8_t phase_cal = 0;

volatile uint16_t distanza_mm = 0;
volatile uint8_t range_status = 0;
volatile int32_t altezza_mm = 0;
volatile uint32_t durata_ultima_misura_ms = 0;


volatile uint8_t control_due = 0;
volatile uint8_t control_busy = 0;
volatile uint8_t control_enabled = 0;
volatile uint32_t control_overrun_count = 0;

/* Variabili controllo PID. */
volatile int32_t setpoint_attuale_mm = 0;
volatile int32_t errore_mm = 0;

/* Variabili PID in scala: 1% = PID_SCALE unita'. */
volatile int32_t p_term_scaled = 0;
volatile int32_t i_term_scaled = 0;
volatile int32_t i_accumulator_scaled = 0;
volatile int32_t d_term_scaled = 0;

volatile uint8_t anti_windup_blocked = 0;
volatile int32_t altezza_precedente_mm = 0;
volatile int32_t delta_altezza_mm = 0;
volatile uint8_t derivative_initialized = 0;

/* Duty in scala: 1% = PID_SCALE unita'. */
volatile int32_t duty_raw_scaled = 0;
volatile int32_t duty_applicato_scaled = 0;


uint8_t invalid_measurement_count = 0;
uint32_t last_uart_log_ms = 0;

/* Modalita riferimento selezionabile da PuTTY. */
volatile ControlMode_t control_mode = DEFAULT_CONTROL_MODE;
uint32_t sine_start_ms = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

void UART_InviaStringa(const char *testo);
void UART_PrintModeHelp(void);
void UART_SelectInitialModeBlocking(void);
void UART_ProcessModeInput(void);
void VL53L0X_VerificaErrore(VL53L0X_Error stato, const char *fase);
void VL53L0X_InitComplete(void);


void Motor_SetDutyScaled(int32_t duty_scaled);
void Motor_DirectionUp(void);
void Motor_Stop(void);

uint8_t EmergencyStopRequested(void);
int32_t ClampI32(int32_t value, int32_t min_value, int32_t max_value);
void FormatScaledPercent(int32_t value_scaled, char *buffer, size_t buffer_size);
uint8_t Sensor_ReadOnceTimed(void);

void Control_Init(void);
void Control_UpdateOnce(void);
void Control_EmergencyStop(const char *motivo);
void Control_SetMode(ControlMode_t nuova_mode);
void Control_UpdateReference(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void UART_InviaStringa(const char *testo)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)testo, strlen(testo), HAL_MAX_DELAY);
}

void UART_PrintModeHelp(void)
{
    UART_InviaStringa("\r\nComandi PuTTY modalita riferimento:\r\n");
    UART_InviaStringa("  0 = SETPOINT FISSO a 450 mm\r\n");
    UART_InviaStringa("  1 = SINUSOIDE 375-525 mm, centro 450 mm, periodo 15 s\r\n");
    UART_InviaStringa("Invia solo il carattere 0 oppure 1.\r\n\r\n");
}

void Control_SetMode(ControlMode_t nuova_mode)
{
    if (nuova_mode == CONTROL_MODE_SETPOINT)
    {
        control_mode = CONTROL_MODE_SETPOINT;
        setpoint_attuale_mm = SETPOINT_FINAL_MM;

        UART_InviaStringa("\r\nMODE = 0 -> SETPOINT FISSO a 450 mm\r\n");
    }
    else if (nuova_mode == CONTROL_MODE_SINE)
    {
        control_mode = CONTROL_MODE_SINE;

        sine_start_ms = HAL_GetTick();

        UART_InviaStringa("\r\nMODE = 1 -> SINUSOIDE 375-525 mm | centro=450 mm | ampiezza=75 mm | periodo=15 s\r\n");
    }
}

void UART_ProcessModeInput(void)
{
    uint8_t rx_byte = 0;

    if (HAL_UART_Receive(&huart2, &rx_byte, 1, 0) == HAL_OK)
    {
        if (rx_byte == '0')
        {
            Control_SetMode(CONTROL_MODE_SETPOINT);
        }
        else if (rx_byte == '1')
        {
            Control_SetMode(CONTROL_MODE_SINE);
        }
        else if ((rx_byte == 'h') || (rx_byte == 'H') || (rx_byte == '?'))
        {
            UART_PrintModeHelp();
        }
        else if ((rx_byte == '\r') || (rx_byte == '\n'))
        {
            /* Ignora eventuali comandi di invio. */
        }
        else
        {
            UART_InviaStringa("Comando non valido. Usa 0=setpoint fisso, 1=sinusoide, h=help.\r\n");
        }
    }
}

void UART_SelectInitialModeBlocking(void)
{
    uint8_t rx_byte = 0;

    UART_PrintModeHelp();
    UART_InviaStringa("ATTESA INPUT: scegli la modalita PRIMA di avviare il motore.\r\n");
    UART_InviaStringa("Digita 0 oppure 1 su PuTTY: ");

    while (1)
    {
        /* Chiamata BLOCCANTE: il programma resta qui finche non arriva un carattere. */
        if (HAL_UART_Receive(&huart2, &rx_byte, 1, HAL_MAX_DELAY) == HAL_OK)
        {
            if (rx_byte == '0')
            {
                UART_InviaStringa("0\r\n");
                Control_SetMode(CONTROL_MODE_SETPOINT);
                return;
            }
            else if (rx_byte == '1')
            {
                UART_InviaStringa("1\r\n");
                Control_SetMode(CONTROL_MODE_SINE);
                return;
            }
            else if ((rx_byte == '\r') || (rx_byte == '\n'))
            {
                /* Ignoro INVIO. */
            }
            else
            {
                UART_InviaStringa("\r\nComando non valido. Digita 0 oppure 1: ");
            }
        }
    }
}

void Control_UpdateReference(void)
{
    if (control_mode == CONTROL_MODE_SINE)
    {
        uint32_t t_ms = HAL_GetTick() - sine_start_ms;

        float phase = (2.0f * 3.14159265359f * (float)t_ms) / (float)SINE_PERIOD_MS;
        float sp_float = (float)SINE_CENTER_MM +
                         ((float)SINE_AMPLITUDE_MM * sinf(phase));

        /* voglio arrotondare al millimetro più vicino. */
        int32_t sp = (int32_t)(sp_float + 0.5f);

        /* Protezione numerica: la sinusoide deve restare nel range 375-525 mm. */
        setpoint_attuale_mm = ClampI32(sp,
                                       SINE_CENTER_MM - SINE_AMPLITUDE_MM,
                                       SINE_CENTER_MM + SINE_AMPLITUDE_MM);
    }
    else
    {
        setpoint_attuale_mm = SETPOINT_FINAL_MM;
    }
}

void VL53L0X_VerificaErrore(VL53L0X_Error stato, const char *fase)
{
    if (stato != VL53L0X_ERROR_NONE)
    {
        snprintf(messaggio_uart, sizeof(messaggio_uart),
                 "Errore in %s: %d\r\n", fase, (int)stato);
        UART_InviaStringa(messaggio_uart);
        Error_Handler();
    }
    else
    {
        snprintf(messaggio_uart, sizeof(messaggio_uart),
                 "%s OK\r\n", fase);
        UART_InviaStringa(messaggio_uart);
    }
}

void VL53L0X_InitComplete(void)
{
#if SENSOR_TEST_ENABLE
    HAL_Delay(100);

    if (HAL_I2C_IsDeviceReady(&hi2c1, VL53L0X_ADDRESS_HAL, 3, 100) == HAL_OK)
    {
        sensore_trovato = 1;
        errore_i2c = 0;
        UART_InviaStringa("VL53L0X trovato su I2C\r\n");
    }
    else
    {
        sensore_trovato = 0;
        errore_i2c = HAL_I2C_GetError(&hi2c1);

        snprintf(messaggio_uart, sizeof(messaggio_uart),
                 "VL53L0X non trovato. Errore I2C: %lu\r\n",
                 (unsigned long)errore_i2c);
        UART_InviaStringa(messaggio_uart);
        Error_Handler();
    }

    memset(&sensore, 0, sizeof(sensore));
    sensore.I2cHandle = &hi2c1;
    sensore.I2cDevAddr = VL53L0X_ADDRESS_HAL;

    UART_InviaStringa("Inizializzazione VL53L0X...\r\n");

    stato_vl53 = VL53L0X_DataInit(&sensore);
    VL53L0X_VerificaErrore(stato_vl53, "VL53L0X_DataInit");

    stato_vl53 = VL53L0X_StaticInit(&sensore);
    VL53L0X_VerificaErrore(stato_vl53, "VL53L0X_StaticInit");

    stato_vl53 = VL53L0X_PerformRefSpadManagement(&sensore,
                                                   &ref_spad_count,
                                                   &is_aperture_spads);
    VL53L0X_VerificaErrore(stato_vl53, "VL53L0X_PerformRefSpadManagement");

    stato_vl53 = VL53L0X_PerformRefCalibration(&sensore,
                                                &vhv_settings,
                                                &phase_cal);
    VL53L0X_VerificaErrore(stato_vl53, "VL53L0X_PerformRefCalibration");

    stato_vl53 = VL53L0X_SetDeviceMode(&sensore,
                                        VL53L0X_DEVICEMODE_SINGLE_RANGING);
    VL53L0X_VerificaErrore(stato_vl53, "VL53L0X_SetDeviceMode");

    UART_InviaStringa("VL53L0X inizializzato correttamente\r\n");
#else
    UART_InviaStringa("SENSOR_TEST_ENABLE = 0: sensore disabilitato.\r\n");
#endif
}


void Motor_SetDutyScaled(int32_t duty_scaled)
{
    if (duty_scaled < 0)
    {
        duty_scaled = 0;
    }

    if (duty_scaled > (100 * PID_SCALE))
    {
        duty_scaled = 100 * PID_SCALE;
    }

    uint32_t autoreload = __HAL_TIM_GET_AUTORELOAD(&htim3);
    uint64_t numerator = ((uint64_t)(autoreload + 1) * (uint64_t)duty_scaled);
    uint32_t denominator = 100U * PID_SCALE;

    /* Arrotondamento al tick PWM piu' vicino. */
    uint32_t pulse = (uint32_t)((numerator + (denominator / 2U)) / denominator);
    //sommare denominator/2 è trucco per fare arrotondamento piu vicino

    if (pulse > autoreload)
    {
        pulse = autoreload;
    }

    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulse);
}

void Motor_DirectionUp(void)
{
    HAL_GPIO_WritePin(L298N_IN1_GPIO_Port, L298N_IN1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(L298N_IN2_GPIO_Port, L298N_IN2_Pin, GPIO_PIN_RESET);
}

void Motor_Stop(void)
{
    Motor_SetDutyScaled(0);
    duty_applicato_scaled = 0;

    HAL_GPIO_WritePin(L298N_IN1_GPIO_Port, L298N_IN1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(L298N_IN2_GPIO_Port, L298N_IN2_Pin, GPIO_PIN_RESET);
}

uint8_t EmergencyStopRequested(void)
{
#if ENABLE_BUTTON_EMERGENCY_STOP
    if (HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin) == GPIO_PIN_RESET)
    {
        return 1;
    }
#endif

    return 0;
}

int32_t ClampI32(int32_t value, int32_t min_value, int32_t max_value)
{
    if (value > max_value)
    {
        return max_value;
    }

    if (value < min_value)
    {
        return min_value;
    }

    return value;
}

void FormatScaledPercent(int32_t value_scaled, char *buffer, size_t buffer_size)
{
    const char *sign = "";

    if (value_scaled < 0)
    {
        sign = "-";
        value_scaled = -value_scaled;
    }

    int32_t integer_part = value_scaled / PID_SCALE;
    int32_t fractional_part = value_scaled % PID_SCALE;

    snprintf(buffer, buffer_size, "%s%ld.%03ld",
             sign,
             (long)integer_part,
             (long)fractional_part);
}

uint8_t Sensor_ReadOnceTimed(void)
{
#if SENSOR_TEST_ENABLE
    uint32_t t0 = HAL_GetTick();

    stato_vl53 = VL53L0X_PerformSingleRangingMeasurement(&sensore, &misura);

    durata_ultima_misura_ms = HAL_GetTick() - t0;

    if (stato_vl53 != VL53L0X_ERROR_NONE)
    {
        return 0;
    }

    distanza_mm = misura.RangeMilliMeter;
    range_status = misura.RangeStatus;

    if (range_status != 0)
    {
        return 0;
    }

    /* Sensore in alto: altezza dal basso = distanza sensore-fondo - distanza sensore-pallina. */
    altezza_mm = (int32_t)SENSOR_TO_BOTTOM_MM - (int32_t)distanza_mm;

    return 1;
#else
    return 0;
#endif
}


void Control_Init(void)
{
    control_due = 0;
    control_busy = 0;
    control_enabled = 0;
    control_overrun_count = 0;

    errore_mm = 0;
    p_term_scaled = 0;
    i_term_scaled = 0;
    i_accumulator_scaled = 0;
    d_term_scaled = 0;
    anti_windup_blocked = 0;
    altezza_precedente_mm = 0;
    delta_altezza_mm = 0;
    derivative_initialized = 0;
    duty_raw_scaled = 0;
    duty_applicato_scaled = 0;
    invalid_measurement_count = 0;
    last_uart_log_ms = 0;

    /* NON resetto control_mode: la modalita e' stata scelta prima dell'avvio. */
    if (control_mode == CONTROL_MODE_SINE)
    {
        sine_start_ms = HAL_GetTick();
    }

    Motor_Stop();
    Motor_DirectionUp();

    /* Imposto il riferimento iniziale in base alla modalita scelta da PuTTY. */
    Control_UpdateReference();

    /* Lettura iniziale usata solo per inizializzare altezza e derivativo. */
    if (Sensor_ReadOnceTimed())
    {
        altezza_precedente_mm = altezza_mm;
        derivative_initialized = 1;
    }

    snprintf(messaggio_uart, sizeof(messaggio_uart),
             "\r\nCONTROL INIT | h0 = %ld mm | setpoint fisso = %u mm\r\n",
             (long)altezza_mm,
             SETPOINT_FINAL_MM);
    UART_InviaStringa(messaggio_uart);


    snprintf(messaggio_uart, sizeof(messaggio_uart),
             "PID fixed-point | mode iniziale=0 SETPOINT | mode 1=SINE 375-525 mm | FF = %u %% | PID_SCALE = %u unita'/%% | Kp = %d/%d %%/mm | Ki = %d/%d | Kd = %d/%d | Imin = %d %% | Imax = %d %% | Dmax = %u %% | DUTY_MAX = %u %% | NO duty rate limiter\r\n",
             DUTY_FEEDFORWARD_PERCENT,
             PID_SCALE,
             KP_NUM,
             KP_DEN,
             KI_NUM,
             KI_DEN,
             KD_NUM,
             KD_DEN,
             I_TERM_MIN_PERCENT,
             I_TERM_MAX_PERCENT,
             D_TERM_MAX_PERCENT,
             DUTY_MAX);
    UART_InviaStringa(messaggio_uart);

    /* Partenza reale dal duty base: il PID aggiunge poi P + I + D. */
    duty_raw_scaled = DUTY_FEEDFORWARD_PERCENT * PID_SCALE;
    duty_applicato_scaled = duty_raw_scaled;

    Motor_SetDutyScaled(duty_applicato_scaled);

    control_enabled = 1;
}

void Control_EmergencyStop(const char *motivo)
{
    control_enabled = 0;
    Motor_Stop();

    snprintf(messaggio_uart, sizeof(messaggio_uart),
             "\r\nARRESTO CONTROLLO: %s\r\n", motivo);
    UART_InviaStringa(messaggio_uart);
}

void Control_UpdateOnce(void)
{
    if (!control_enabled)
    {
        return;
    }

    if (EmergencyStopRequested())
    {
        Control_EmergencyStop("pulsante B1 premuto");
        return;
    }

    uint8_t misura_valida = Sensor_ReadOnceTimed();

    if (!misura_valida)
    {
        invalid_measurement_count++;

        snprintf(messaggio_uart, sizeof(messaggio_uart),
                 "Misura non valida %u/%u | stato_vl53 = %d | status = %u | Tmis = %lu ms\r\n",
                 invalid_measurement_count,
                 MAX_INVALID_MEASUREMENTS,
                 (int)stato_vl53,
                 range_status,
                 (unsigned long)durata_ultima_misura_ms);
        UART_InviaStringa(messaggio_uart);

        if (invalid_measurement_count >= MAX_INVALID_MEASUREMENTS)
        {
            Control_EmergencyStop("troppe misure VL53L0X non valide");
        }

        return;
    }

    invalid_measurement_count = 0;

    Control_UpdateReference();

    errore_mm = setpoint_attuale_mm - altezza_mm;

    p_term_scaled = (int32_t)(((int64_t)KP_NUM * errore_mm * PID_SCALE) / KP_DEN);

    if (!derivative_initialized)
    {
        altezza_precedente_mm = altezza_mm;
        delta_altezza_mm = 0;
        d_term_scaled = 0;
        derivative_initialized = 1;
    }
    else
    {
        delta_altezza_mm = altezza_mm - altezza_precedente_mm;
        altezza_precedente_mm = altezza_mm;

        d_term_scaled = (int32_t)(-(((int64_t)KD_NUM * delta_altezza_mm * PID_SCALE) / KD_DEN));

        d_term_scaled = ClampI32(d_term_scaled,
                                 -D_TERM_MAX_PERCENT * PID_SCALE,
                                  D_TERM_MAX_PERCENT * PID_SCALE);

    }

    int32_t i_increment_scaled =
        (int32_t)(((int64_t)KI_NUM * errore_mm * I_TERM_SCALE) / KI_DEN);

    int32_t i_candidate_scaled = i_accumulator_scaled + i_increment_scaled;

    i_candidate_scaled = ClampI32(i_candidate_scaled,
                                  I_TERM_MIN_PERCENT * I_TERM_SCALE,
                                  I_TERM_MAX_PERCENT * I_TERM_SCALE);

    int32_t raw_candidate_scaled =
        (DUTY_FEEDFORWARD_PERCENT * PID_SCALE) +
        p_term_scaled +
        i_candidate_scaled +
        d_term_scaled;

    anti_windup_blocked = 0;

    if ((raw_candidate_scaled > (DUTY_MAX * PID_SCALE)) && (errore_mm > 0))
    {
        anti_windup_blocked = 1;
    }

    if ((raw_candidate_scaled < (DUTY_MIN * PID_SCALE)) && (errore_mm < 0))
    {
        anti_windup_blocked = 1;
    }

    if (!anti_windup_blocked)
    {
        i_accumulator_scaled = i_candidate_scaled;
    }

    i_term_scaled = i_accumulator_scaled;

    /*Duty richiesto dal PID*/
    duty_raw_scaled =
        (DUTY_FEEDFORWARD_PERCENT * PID_SCALE) +
        p_term_scaled +
        i_term_scaled +
        d_term_scaled;


    /* saturazione: impedisco valori fuori dal range sicuro. */
    duty_applicato_scaled = ClampI32(duty_raw_scaled,
                                  DUTY_MIN * PID_SCALE,
                                  DUTY_MAX * PID_SCALE);


    /* applico il duty reale al motore usando il valore scalato. */
    Motor_SetDutyScaled(duty_applicato_scaled);

    /* log UART ogni 300 ms sennò controllo troppo lento */
    uint32_t now = HAL_GetTick();

    if ((now - last_uart_log_ms) >= UART_LOG_PERIOD_MS)
    {
        last_uart_log_ms = now;

        char p_str[18];
        char i_str[18];
        char d_str[18];
        char appl_str[18];

        FormatScaledPercent(p_term_scaled, p_str, sizeof(p_str));
        FormatScaledPercent(i_term_scaled, i_str, sizeof(i_str));
        FormatScaledPercent(d_term_scaled, d_str, sizeof(d_str));
        FormatScaledPercent(duty_applicato_scaled, appl_str, sizeof(appl_str));

        snprintf(messaggio_uart, sizeof(messaggio_uart),
                 "CTRL | mode=%u | sp=%ld mm | h=%ld mm | err=%ld mm | P=%s %% | I=%s %% | D=%s %%  | appl=%s %% | aw=%u | Tmis=%lu ms | ov=%lu\r\n",
                 (unsigned int)control_mode,
                 (long)setpoint_attuale_mm,
                 (long)altezza_mm,
                 (long)errore_mm,
                 p_str,
                 i_str,
                 d_str,
                 appl_str,
                 anti_windup_blocked,
                 (unsigned long)durata_ultima_misura_ms,
                 (unsigned long)control_overrun_count);
        UART_InviaStringa(messaggio_uart);
    }
}

/*
 * ricordati che la callback è chiamata dalla HAL quando un timer in interrupt scade.

 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM4)
    {

        if (control_due || control_busy)
        {
            control_overrun_count++;
        }
        else
        {
            control_due = 1;
        }
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */

    UART_InviaStringa("\r\n");
    UART_InviaStringa("Avvio controllo PID con timer TIM4\r\n");

    VL53L0X_InitComplete();

    UART_InviaStringa("Avvio PWM motore su TIM3_CH1...\r\n");

    if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1) != HAL_OK)
    {
        UART_InviaStringa("Errore avvio PWM motore\r\n");
        Error_Handler();
    }

    Motor_Stop();
    UART_InviaStringa("PWM pronto. Motore fermo.\r\n");


#if PID_CONTROL_ENABLE
    UART_SelectInitialModeBlocking();

    Control_Init();

    UART_InviaStringa("Avvio TIM4 interrupt per controllo PID...\r\n");

    if (HAL_TIM_Base_Start_IT(&htim4) != HAL_OK)
    {
        UART_InviaStringa("Errore avvio TIM4 interrupt\r\n");
        Error_Handler();
    }
#else
    UART_InviaStringa("PID_CONTROL_ENABLE = 0: controllo disabilitato.\r\n");
#endif

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
#if PID_CONTROL_ENABLE
      UART_ProcessModeInput();

      if (control_due && control_enabled)
      {
          control_due = 0;
          control_busy = 1;

          Control_UpdateOnce();

          control_busy = 0;
      }

      if (!control_enabled)
      {
          Motor_Stop();
          HAL_Delay(1000);
      }
#else
      HAL_Delay(1000);
#endif

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  Motor_Stop();
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
